/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/s29/Denisov/tapc/fsm.v";
static int ng1[] = {16, 0};
static int ng2[] = {4, 0};
static int ng3[] = {3, 0};
static int ng4[] = {1, 0};
static int ng5[] = {2, 0};
static int ng6[] = {0, 0};



static void Always_48_0(char *t0)
{
    char t14[8];
    char t22[8];
    char t25[8];
    char t26[8];
    char t28[8];
    char t36[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    char *t13;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t23;
    char *t24;
    char *t27;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    char *t33;
    unsigned int t34;
    int t35;

LAB0:    t1 = (t0 + 3000U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(48, ng0);
    t2 = (t0 + 3320);
    *((int *)t2) = 1;
    t3 = (t0 + 3032);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(48, ng0);

LAB5:    xsi_set_current_line(49, ng0);
    t4 = (t0 + 1528U);
    t5 = *((char **)t4);
    t4 = (t5 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB6;

LAB7:    xsi_set_current_line(55, ng0);

LAB18:    xsi_set_current_line(56, ng0);
    t2 = (t0 + 1208U);
    t3 = *((char **)t2);
    t2 = (t0 + 1928);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 4, 0LL);

LAB8:    goto LAB2;

LAB6:    xsi_set_current_line(49, ng0);

LAB9:    xsi_set_current_line(50, ng0);
    t11 = (t0 + 2088);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    t15 = (t0 + 2088);
    t16 = (t15 + 72U);
    t17 = *((char **)t16);
    t18 = (t0 + 1928);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    t21 = ((char*)((ng1)));
    memset(t22, 0, 8);
    xsi_vlog_unsigned_multiply(t22, 32, t20, 4, t21, 32);
    t23 = (t0 + 1048U);
    t24 = *((char **)t23);
    memset(t25, 0, 8);
    xsi_vlog_unsigned_add(t25, 32, t22, 32, t24, 4);
    t23 = ((char*)((ng2)));
    memset(t26, 0, 8);
    xsi_vlog_unsigned_multiply(t26, 32, t25, 32, t23, 32);
    xsi_vlog_generic_get_index_select_value(t14, 1, t13, t17, 2, t26, 32, 2);
    t27 = (t0 + 1928);
    t29 = (t0 + 1928);
    t30 = (t29 + 72U);
    t31 = *((char **)t30);
    t32 = ((char*)((ng3)));
    xsi_vlog_generic_convert_bit_index(t28, t31, 2, t32, 32, 1);
    t33 = (t28 + 4);
    t34 = *((unsigned int *)t33);
    t35 = (!(t34));
    if (t35 == 1)
        goto LAB10;

LAB11:    xsi_set_current_line(51, ng0);
    t2 = (t0 + 2088);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 2088);
    t11 = (t5 + 72U);
    t12 = *((char **)t11);
    t13 = (t0 + 1928);
    t15 = (t13 + 56U);
    t16 = *((char **)t15);
    t17 = ((char*)((ng1)));
    memset(t22, 0, 8);
    xsi_vlog_unsigned_multiply(t22, 32, t16, 4, t17, 32);
    t18 = (t0 + 1048U);
    t19 = *((char **)t18);
    memset(t25, 0, 8);
    xsi_vlog_unsigned_add(t25, 32, t22, 32, t19, 4);
    t18 = ((char*)((ng2)));
    memset(t26, 0, 8);
    xsi_vlog_unsigned_multiply(t26, 32, t25, 32, t18, 32);
    t20 = ((char*)((ng4)));
    memset(t28, 0, 8);
    xsi_vlog_unsigned_add(t28, 32, t26, 32, t20, 32);
    xsi_vlog_generic_get_index_select_value(t14, 1, t4, t12, 2, t28, 32, 2);
    t21 = (t0 + 1928);
    t23 = (t0 + 1928);
    t24 = (t23 + 72U);
    t27 = *((char **)t24);
    t29 = ((char*)((ng5)));
    xsi_vlog_generic_convert_bit_index(t36, t27, 2, t29, 32, 1);
    t30 = (t36 + 4);
    t6 = *((unsigned int *)t30);
    t35 = (!(t6));
    if (t35 == 1)
        goto LAB12;

LAB13:    xsi_set_current_line(52, ng0);
    t2 = (t0 + 2088);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 2088);
    t11 = (t5 + 72U);
    t12 = *((char **)t11);
    t13 = (t0 + 1928);
    t15 = (t13 + 56U);
    t16 = *((char **)t15);
    t17 = ((char*)((ng1)));
    memset(t22, 0, 8);
    xsi_vlog_unsigned_multiply(t22, 32, t16, 4, t17, 32);
    t18 = (t0 + 1048U);
    t19 = *((char **)t18);
    memset(t25, 0, 8);
    xsi_vlog_unsigned_add(t25, 32, t22, 32, t19, 4);
    t18 = ((char*)((ng2)));
    memset(t26, 0, 8);
    xsi_vlog_unsigned_multiply(t26, 32, t25, 32, t18, 32);
    t20 = ((char*)((ng5)));
    memset(t28, 0, 8);
    xsi_vlog_unsigned_add(t28, 32, t26, 32, t20, 32);
    xsi_vlog_generic_get_index_select_value(t14, 1, t4, t12, 2, t28, 32, 2);
    t21 = (t0 + 1928);
    t23 = (t0 + 1928);
    t24 = (t23 + 72U);
    t27 = *((char **)t24);
    t29 = ((char*)((ng4)));
    xsi_vlog_generic_convert_bit_index(t36, t27, 2, t29, 32, 1);
    t30 = (t36 + 4);
    t6 = *((unsigned int *)t30);
    t35 = (!(t6));
    if (t35 == 1)
        goto LAB14;

LAB15:    xsi_set_current_line(53, ng0);
    t2 = (t0 + 2088);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 2088);
    t11 = (t5 + 72U);
    t12 = *((char **)t11);
    t13 = (t0 + 1928);
    t15 = (t13 + 56U);
    t16 = *((char **)t15);
    t17 = ((char*)((ng1)));
    memset(t22, 0, 8);
    xsi_vlog_unsigned_multiply(t22, 32, t16, 4, t17, 32);
    t18 = (t0 + 1048U);
    t19 = *((char **)t18);
    memset(t25, 0, 8);
    xsi_vlog_unsigned_add(t25, 32, t22, 32, t19, 4);
    t18 = ((char*)((ng2)));
    memset(t26, 0, 8);
    xsi_vlog_unsigned_multiply(t26, 32, t25, 32, t18, 32);
    t20 = ((char*)((ng3)));
    memset(t28, 0, 8);
    xsi_vlog_unsigned_add(t28, 32, t26, 32, t20, 32);
    xsi_vlog_generic_get_index_select_value(t14, 1, t4, t12, 2, t28, 32, 2);
    t21 = (t0 + 1928);
    t23 = (t0 + 1928);
    t24 = (t23 + 72U);
    t27 = *((char **)t24);
    t29 = ((char*)((ng6)));
    xsi_vlog_generic_convert_bit_index(t36, t27, 2, t29, 32, 1);
    t30 = (t36 + 4);
    t6 = *((unsigned int *)t30);
    t35 = (!(t6));
    if (t35 == 1)
        goto LAB16;

LAB17:    goto LAB8;

LAB10:    xsi_vlogvar_wait_assign_value(t27, t14, 0, *((unsigned int *)t28), 1, 0LL);
    goto LAB11;

LAB12:    xsi_vlogvar_wait_assign_value(t21, t14, 0, *((unsigned int *)t36), 1, 0LL);
    goto LAB13;

LAB14:    xsi_vlogvar_wait_assign_value(t21, t14, 0, *((unsigned int *)t36), 1, 0LL);
    goto LAB15;

LAB16:    xsi_vlogvar_wait_assign_value(t21, t14, 0, *((unsigned int *)t36), 1, 0LL);
    goto LAB17;

}


extern void work_m_13722721145802346420_2030911003_init()
{
	static char *pe[] = {(void *)Always_48_0};
	xsi_register_didat("work_m_13722721145802346420_2030911003", "isim/main_module_tb_isim_beh.exe.sim/work/m_13722721145802346420_2030911003.didat");
	xsi_register_executes(pe);
}
