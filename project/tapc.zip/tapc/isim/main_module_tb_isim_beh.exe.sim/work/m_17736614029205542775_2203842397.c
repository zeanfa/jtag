/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/s29/Denisov/tapc/main_module_tb.v";
static int ng1[] = {0, 0};
static int ng2[] = {1, 0};
static int ng3[] = {5, 0};
static unsigned int ng4[] = {5U, 0U};
static unsigned int ng5[] = {3U, 0U};
static unsigned int ng6[] = {7U, 0U};
static unsigned int ng7[] = {0U, 0U};
static int ng8[] = {10, 0};



static int sp_command(char *t1, char *t2)
{
    char t15[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    int t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 2072);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(108, ng0);

LAB5:    xsi_set_current_line(109, ng0);
    t5 = ((char*)((ng1)));
    t6 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t6, t5, 0, 0, 1, 0LL);
    xsi_set_current_line(109, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t4 + 4);
    t7 = *((unsigned int *)t5);
    t8 = (~(t7));
    t9 = *((unsigned int *)t4);
    t10 = (t9 & t8);
    t6 = (t1 + 10568);
    *((int *)t6) = t10;

LAB6:    t11 = (t1 + 10568);
    if (*((int *)t11) > 0)
        goto LAB7;

LAB8:    xsi_set_current_line(110, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(110, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 16U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB10;

LAB1:    return t0;
LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;
    goto LAB1;

LAB7:    xsi_set_current_line(109, ng0);
    t12 = (t2 + 88U);
    t13 = *((char **)t12);
    t14 = (t13 + 0U);
    xsi_wp_set_status(t14, 1);
    *((char **)t3) = &&LAB9;
    goto LAB1;

LAB9:    t4 = (t1 + 10568);
    t10 = *((int *)t4);
    *((int *)t4) = (t10 - 1);
    goto LAB6;

LAB10:    xsi_set_current_line(111, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(111, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 32U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB11;
    goto LAB1;

LAB11:    xsi_set_current_line(112, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(112, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 48U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB12;
    goto LAB1;

LAB12:    xsi_set_current_line(113, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(113, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 64U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB13;
    goto LAB1;

LAB13:    xsi_set_current_line(115, ng0);
    t4 = (t1 + 5616);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memset(t15, 0, 8);
    t11 = (t15 + 4);
    t12 = (t6 + 4);
    t7 = *((unsigned int *)t6);
    t8 = (t7 >> 0);
    t9 = (t8 & 1);
    *((unsigned int *)t15) = t9;
    t16 = *((unsigned int *)t12);
    t17 = (t16 >> 0);
    t18 = (t17 & 1);
    *((unsigned int *)t11) = t18;
    t13 = (t1 + 4176);
    xsi_vlogvar_wait_assign_value(t13, t15, 0, 0, 1, 0LL);
    xsi_set_current_line(115, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(115, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 80U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB14;
    goto LAB1;

LAB14:    xsi_set_current_line(116, ng0);
    t4 = (t1 + 5616);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memset(t15, 0, 8);
    t11 = (t15 + 4);
    t12 = (t6 + 4);
    t7 = *((unsigned int *)t6);
    t8 = (t7 >> 1);
    t9 = (t8 & 1);
    *((unsigned int *)t15) = t9;
    t16 = *((unsigned int *)t12);
    t17 = (t16 >> 1);
    t18 = (t17 & 1);
    *((unsigned int *)t11) = t18;
    t13 = (t1 + 4176);
    xsi_vlogvar_wait_assign_value(t13, t15, 0, 0, 1, 0LL);
    xsi_set_current_line(116, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(116, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 96U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB15;
    goto LAB1;

LAB15:    xsi_set_current_line(117, ng0);
    t4 = (t1 + 5616);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memset(t15, 0, 8);
    t11 = (t15 + 4);
    t12 = (t6 + 4);
    t7 = *((unsigned int *)t6);
    t8 = (t7 >> 2);
    t9 = (t8 & 1);
    *((unsigned int *)t15) = t9;
    t16 = *((unsigned int *)t12);
    t17 = (t16 >> 2);
    t18 = (t17 & 1);
    *((unsigned int *)t11) = t18;
    t13 = (t1 + 4176);
    xsi_vlogvar_wait_assign_value(t13, t15, 0, 0, 1, 0LL);
    xsi_set_current_line(117, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(117, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 112U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB16;
    goto LAB1;

LAB16:    xsi_set_current_line(118, ng0);
    t4 = (t1 + 5616);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memset(t15, 0, 8);
    t11 = (t15 + 4);
    t12 = (t6 + 4);
    t7 = *((unsigned int *)t6);
    t8 = (t7 >> 3);
    t9 = (t8 & 1);
    *((unsigned int *)t15) = t9;
    t16 = *((unsigned int *)t12);
    t17 = (t16 >> 3);
    t18 = (t17 & 1);
    *((unsigned int *)t11) = t18;
    t13 = (t1 + 4176);
    xsi_vlogvar_wait_assign_value(t13, t15, 0, 0, 1, 0LL);
    xsi_set_current_line(118, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(118, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 128U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB17;
    goto LAB1;

LAB17:    xsi_set_current_line(120, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4176);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(120, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(120, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 144U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB18;
    goto LAB1;

LAB18:    xsi_set_current_line(121, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(121, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 160U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB19;
    goto LAB1;

LAB19:    xsi_set_current_line(122, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(122, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 176U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB20;
    goto LAB1;

LAB20:    xsi_set_current_line(123, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(123, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 192U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB21;
    goto LAB1;

LAB21:    goto LAB4;

}

static int sp_data(char *t1, char *t2)
{
    char t7[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    char *t16;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 2504);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(129, ng0);

LAB5:    xsi_set_current_line(130, ng0);
    t5 = ((char*)((ng2)));
    t6 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t6, t5, 0, 0, 1, 0LL);
    xsi_set_current_line(130, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 0U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB6;

LAB1:    return t0;
LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;
    goto LAB1;

LAB6:    xsi_set_current_line(131, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(131, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 16U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB7;
    goto LAB1;

LAB7:    xsi_set_current_line(132, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(132, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 32U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB8;
    goto LAB1;

LAB8:    xsi_set_current_line(138, ng0);
    t4 = (t1 + 5776);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memset(t7, 0, 8);
    t8 = (t7 + 4);
    t9 = (t6 + 4);
    t10 = *((unsigned int *)t6);
    t11 = (t10 >> 0);
    t12 = (t11 & 1);
    *((unsigned int *)t7) = t12;
    t13 = *((unsigned int *)t9);
    t14 = (t13 >> 0);
    t15 = (t14 & 1);
    *((unsigned int *)t8) = t15;
    t16 = (t1 + 4176);
    xsi_vlogvar_wait_assign_value(t16, t7, 0, 0, 1, 0LL);
    xsi_set_current_line(138, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(138, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 48U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB9;
    goto LAB1;

LAB9:    xsi_set_current_line(139, ng0);
    t4 = (t1 + 5776);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memset(t7, 0, 8);
    t8 = (t7 + 4);
    t9 = (t6 + 4);
    t10 = *((unsigned int *)t6);
    t11 = (t10 >> 1);
    t12 = (t11 & 1);
    *((unsigned int *)t7) = t12;
    t13 = *((unsigned int *)t9);
    t14 = (t13 >> 1);
    t15 = (t14 & 1);
    *((unsigned int *)t8) = t15;
    t16 = (t1 + 4176);
    xsi_vlogvar_wait_assign_value(t16, t7, 0, 0, 1, 0LL);
    xsi_set_current_line(139, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(139, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 64U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB10;
    goto LAB1;

LAB10:    xsi_set_current_line(140, ng0);
    t4 = (t1 + 5776);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memset(t7, 0, 8);
    t8 = (t7 + 4);
    t9 = (t6 + 4);
    t10 = *((unsigned int *)t6);
    t11 = (t10 >> 2);
    t12 = (t11 & 1);
    *((unsigned int *)t7) = t12;
    t13 = *((unsigned int *)t9);
    t14 = (t13 >> 2);
    t15 = (t14 & 1);
    *((unsigned int *)t8) = t15;
    t16 = (t1 + 4176);
    xsi_vlogvar_wait_assign_value(t16, t7, 0, 0, 1, 0LL);
    xsi_set_current_line(140, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(140, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 80U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB11;
    goto LAB1;

LAB11:    xsi_set_current_line(141, ng0);
    t4 = (t1 + 5776);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memset(t7, 0, 8);
    t8 = (t7 + 4);
    t9 = (t6 + 4);
    t10 = *((unsigned int *)t6);
    t11 = (t10 >> 3);
    t12 = (t11 & 1);
    *((unsigned int *)t7) = t12;
    t13 = *((unsigned int *)t9);
    t14 = (t13 >> 3);
    t15 = (t14 & 1);
    *((unsigned int *)t8) = t15;
    t16 = (t1 + 4176);
    xsi_vlogvar_wait_assign_value(t16, t7, 0, 0, 1, 0LL);
    xsi_set_current_line(141, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(141, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 96U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB12;
    goto LAB1;

LAB12:    xsi_set_current_line(143, ng0);
    t4 = (t1 + 5776);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memset(t7, 0, 8);
    t8 = (t7 + 4);
    t9 = (t6 + 4);
    t10 = *((unsigned int *)t6);
    t11 = (t10 >> 4);
    t12 = (t11 & 1);
    *((unsigned int *)t7) = t12;
    t13 = *((unsigned int *)t9);
    t14 = (t13 >> 4);
    t15 = (t14 & 1);
    *((unsigned int *)t8) = t15;
    t16 = (t1 + 4176);
    xsi_vlogvar_wait_assign_value(t16, t7, 0, 0, 1, 0LL);
    xsi_set_current_line(143, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(143, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 112U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB13;
    goto LAB1;

LAB13:    xsi_set_current_line(144, ng0);
    t4 = (t1 + 5776);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memset(t7, 0, 8);
    t8 = (t7 + 4);
    t9 = (t6 + 4);
    t10 = *((unsigned int *)t6);
    t11 = (t10 >> 5);
    t12 = (t11 & 1);
    *((unsigned int *)t7) = t12;
    t13 = *((unsigned int *)t9);
    t14 = (t13 >> 5);
    t15 = (t14 & 1);
    *((unsigned int *)t8) = t15;
    t16 = (t1 + 4176);
    xsi_vlogvar_wait_assign_value(t16, t7, 0, 0, 1, 0LL);
    xsi_set_current_line(144, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(144, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 128U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB14;
    goto LAB1;

LAB14:    xsi_set_current_line(145, ng0);
    t4 = (t1 + 5776);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memset(t7, 0, 8);
    t8 = (t7 + 4);
    t9 = (t6 + 4);
    t10 = *((unsigned int *)t6);
    t11 = (t10 >> 6);
    t12 = (t11 & 1);
    *((unsigned int *)t7) = t12;
    t13 = *((unsigned int *)t9);
    t14 = (t13 >> 6);
    t15 = (t14 & 1);
    *((unsigned int *)t8) = t15;
    t16 = (t1 + 4176);
    xsi_vlogvar_wait_assign_value(t16, t7, 0, 0, 1, 0LL);
    xsi_set_current_line(145, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(145, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 144U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB15;
    goto LAB1;

LAB15:    xsi_set_current_line(146, ng0);
    t4 = (t1 + 5776);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memset(t7, 0, 8);
    t8 = (t7 + 4);
    t9 = (t6 + 4);
    t10 = *((unsigned int *)t6);
    t11 = (t10 >> 7);
    t12 = (t11 & 1);
    *((unsigned int *)t7) = t12;
    t13 = *((unsigned int *)t9);
    t14 = (t13 >> 7);
    t15 = (t14 & 1);
    *((unsigned int *)t8) = t15;
    t16 = (t1 + 4176);
    xsi_vlogvar_wait_assign_value(t16, t7, 0, 0, 1, 0LL);
    xsi_set_current_line(146, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(146, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 160U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB16;
    goto LAB1;

LAB16:    xsi_set_current_line(148, ng0);
    t4 = (t1 + 5776);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memset(t7, 0, 8);
    t8 = (t7 + 4);
    t9 = (t6 + 4);
    t10 = *((unsigned int *)t6);
    t11 = (t10 >> 8);
    t12 = (t11 & 1);
    *((unsigned int *)t7) = t12;
    t13 = *((unsigned int *)t9);
    t14 = (t13 >> 8);
    t15 = (t14 & 1);
    *((unsigned int *)t8) = t15;
    t16 = (t1 + 4176);
    xsi_vlogvar_wait_assign_value(t16, t7, 0, 0, 1, 0LL);
    xsi_set_current_line(148, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(148, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 176U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB17;
    goto LAB1;

LAB17:    xsi_set_current_line(149, ng0);
    t4 = (t1 + 5776);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memset(t7, 0, 8);
    t8 = (t7 + 4);
    t9 = (t6 + 4);
    t10 = *((unsigned int *)t6);
    t11 = (t10 >> 9);
    t12 = (t11 & 1);
    *((unsigned int *)t7) = t12;
    t13 = *((unsigned int *)t9);
    t14 = (t13 >> 9);
    t15 = (t14 & 1);
    *((unsigned int *)t8) = t15;
    t16 = (t1 + 4176);
    xsi_vlogvar_wait_assign_value(t16, t7, 0, 0, 1, 0LL);
    xsi_set_current_line(149, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(149, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 192U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB18;
    goto LAB1;

LAB18:    xsi_set_current_line(150, ng0);
    t4 = (t1 + 5776);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memset(t7, 0, 8);
    t8 = (t7 + 4);
    t9 = (t6 + 4);
    t10 = *((unsigned int *)t6);
    t11 = (t10 >> 10);
    t12 = (t11 & 1);
    *((unsigned int *)t7) = t12;
    t13 = *((unsigned int *)t9);
    t14 = (t13 >> 10);
    t15 = (t14 & 1);
    *((unsigned int *)t8) = t15;
    t16 = (t1 + 4176);
    xsi_vlogvar_wait_assign_value(t16, t7, 0, 0, 1, 0LL);
    xsi_set_current_line(150, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(150, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 208U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB19;
    goto LAB1;

LAB19:    xsi_set_current_line(152, ng0);
    t4 = (t1 + 5776);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memset(t7, 0, 8);
    t8 = (t7 + 4);
    t9 = (t6 + 4);
    t10 = *((unsigned int *)t6);
    t11 = (t10 >> 11);
    t12 = (t11 & 1);
    *((unsigned int *)t7) = t12;
    t13 = *((unsigned int *)t9);
    t14 = (t13 >> 11);
    t15 = (t14 & 1);
    *((unsigned int *)t8) = t15;
    t16 = (t1 + 4176);
    xsi_vlogvar_wait_assign_value(t16, t7, 0, 0, 1, 0LL);
    xsi_set_current_line(152, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(152, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 224U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB20;
    goto LAB1;

LAB20:    xsi_set_current_line(153, ng0);
    t4 = (t1 + 5776);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memset(t7, 0, 8);
    t8 = (t7 + 4);
    t9 = (t6 + 4);
    t10 = *((unsigned int *)t6);
    t11 = (t10 >> 12);
    t12 = (t11 & 1);
    *((unsigned int *)t7) = t12;
    t13 = *((unsigned int *)t9);
    t14 = (t13 >> 12);
    t15 = (t14 & 1);
    *((unsigned int *)t8) = t15;
    t16 = (t1 + 4176);
    xsi_vlogvar_wait_assign_value(t16, t7, 0, 0, 1, 0LL);
    xsi_set_current_line(153, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(153, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 240U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB21;
    goto LAB1;

LAB21:    xsi_set_current_line(159, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4176);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(159, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(159, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 256U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB22;
    goto LAB1;

LAB22:    xsi_set_current_line(160, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4176);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(160, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(160, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 272U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB23;
    goto LAB1;

LAB23:    xsi_set_current_line(161, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4176);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(161, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(161, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 288U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB24;
    goto LAB1;

LAB24:    xsi_set_current_line(162, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4176);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(162, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(162, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 304U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB25;
    goto LAB1;

LAB25:    xsi_set_current_line(164, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(164, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 320U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB26;
    goto LAB1;

LAB26:    xsi_set_current_line(165, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(165, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 336U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB27;
    goto LAB1;

LAB27:    xsi_set_current_line(166, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(166, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 352U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB28;
    goto LAB1;

LAB28:    xsi_set_current_line(167, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(167, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 368U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB29;
    goto LAB1;

LAB29:    xsi_set_current_line(168, ng0);
    t4 = ((char*)((ng1)));
    t5 = (t1 + 4336);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 1, 0LL);
    xsi_set_current_line(168, ng0);
    t4 = (t2 + 88U);
    t5 = *((char **)t4);
    t6 = (t5 + 384U);
    xsi_wp_set_status(t6, 1);
    *((char **)t3) = &&LAB30;
    goto LAB1;

LAB30:    goto LAB4;

}

static void Always_92_0(char *t0)
{
    char t3[8];
    char *t1;
    char *t2;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    char *t24;

LAB0:    t1 = (t0 + 6688U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(92, ng0);

LAB4:    xsi_set_current_line(93, ng0);
    t2 = (t0 + 6496);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB5;

LAB1:    return;
LAB5:    xsi_set_current_line(93, ng0);
    t4 = (t0 + 4496);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memset(t3, 0, 8);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB9;

LAB7:    if (*((unsigned int *)t7) == 0)
        goto LAB6;

LAB8:    t13 = (t3 + 4);
    *((unsigned int *)t3) = 1;
    *((unsigned int *)t13) = 1;

LAB9:    t14 = (t3 + 4);
    t15 = (t6 + 4);
    t16 = *((unsigned int *)t6);
    t17 = (~(t16));
    *((unsigned int *)t3) = t17;
    *((unsigned int *)t14) = 0;
    if (*((unsigned int *)t15) != 0)
        goto LAB11;

LAB10:    t22 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t22 & 1U);
    t23 = *((unsigned int *)t14);
    *((unsigned int *)t14) = (t23 & 1U);
    t24 = (t0 + 4496);
    xsi_vlogvar_wait_assign_value(t24, t3, 0, 0, 1, 0LL);
    goto LAB2;

LAB6:    *((unsigned int *)t3) = 1;
    goto LAB9;

LAB11:    t18 = *((unsigned int *)t3);
    t19 = *((unsigned int *)t15);
    *((unsigned int *)t3) = (t18 | t19);
    t20 = *((unsigned int *)t14);
    t21 = *((unsigned int *)t15);
    *((unsigned int *)t14) = (t20 | t21);
    goto LAB10;

}

static void Always_96_1(char *t0)
{
    char t3[8];
    char *t1;
    char *t2;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    char *t24;

LAB0:    t1 = (t0 + 6936U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(96, ng0);

LAB4:    xsi_set_current_line(97, ng0);
    t2 = (t0 + 6744);
    xsi_process_wait(t2, 2000LL);
    *((char **)t1) = &&LAB5;

LAB1:    return;
LAB5:    xsi_set_current_line(97, ng0);
    t4 = (t0 + 4816);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memset(t3, 0, 8);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB9;

LAB7:    if (*((unsigned int *)t7) == 0)
        goto LAB6;

LAB8:    t13 = (t3 + 4);
    *((unsigned int *)t3) = 1;
    *((unsigned int *)t13) = 1;

LAB9:    t14 = (t3 + 4);
    t15 = (t6 + 4);
    t16 = *((unsigned int *)t6);
    t17 = (~(t16));
    *((unsigned int *)t3) = t17;
    *((unsigned int *)t14) = 0;
    if (*((unsigned int *)t15) != 0)
        goto LAB11;

LAB10:    t22 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t22 & 1U);
    t23 = *((unsigned int *)t14);
    *((unsigned int *)t14) = (t23 & 1U);
    t24 = (t0 + 4816);
    xsi_vlogvar_wait_assign_value(t24, t3, 0, 0, 1, 0LL);
    goto LAB2;

LAB6:    *((unsigned int *)t3) = 1;
    goto LAB9;

LAB11:    t18 = *((unsigned int *)t3);
    t19 = *((unsigned int *)t15);
    *((unsigned int *)t3) = (t18 | t19);
    t20 = *((unsigned int *)t14);
    t21 = *((unsigned int *)t15);
    *((unsigned int *)t14) = (t20 | t21);
    goto LAB10;

}

static void Initial_100_2(char *t0)
{
    char *t1;
    char *t2;
    char *t3;

LAB0:    t1 = (t0 + 7184U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(100, ng0);

LAB4:    xsi_set_current_line(101, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4496);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(101, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 4336);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(101, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 4656);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(101, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4176);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(101, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4816);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(101, ng0);
    t2 = (t0 + 7752);
    *((int *)t2) = 1;
    t3 = (t0 + 7216);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB5;

LAB1:    return;
LAB5:    xsi_set_current_line(102, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 4656);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(102, ng0);
    t2 = (t0 + 7768);
    *((int *)t2) = 1;
    t3 = (t0 + 7216);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB6;
    goto LAB1;

LAB6:    xsi_set_current_line(103, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 4656);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(103, ng0);
    t2 = (t0 + 7784);
    *((int *)t2) = 1;
    t3 = (t0 + 7216);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB7;
    goto LAB1;

LAB7:    goto LAB1;

}

static void Initial_172_3(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    int t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;

LAB0:    t1 = (t0 + 7432U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(172, ng0);

LAB4:    xsi_set_current_line(174, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t2 + 4);
    t4 = *((unsigned int *)t3);
    t5 = (~(t4));
    t6 = *((unsigned int *)t2);
    t7 = (t6 & t5);
    t8 = (t0 + 10572);
    *((int *)t8) = t7;

LAB5:    t9 = (t0 + 10572);
    if (*((int *)t9) > 0)
        goto LAB6;

LAB7:    xsi_set_current_line(176, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 7240);
    t8 = (t0 + 2072);
    t9 = xsi_create_subprogram_invocation(t3, 0, t0, t8, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t8, t9);
    t10 = (t0 + 5616);
    xsi_vlogvar_assign_value(t10, t2, 0, 0, 4);

LAB11:    t11 = (t0 + 7336);
    t12 = *((char **)t11);
    t13 = (t12 + 80U);
    t14 = *((char **)t13);
    t15 = (t14 + 272U);
    t16 = *((char **)t15);
    t17 = (t16 + 0U);
    t18 = *((char **)t17);
    t7 = ((int  (*)(char *, char *))t18)(t0, t12);

LAB13:    if (t7 != 0)
        goto LAB14;

LAB9:    t12 = (t0 + 2072);
    xsi_vlog_subprogram_popinvocation(t12);

LAB10:    t19 = (t0 + 7336);
    t20 = *((char **)t19);
    t19 = (t0 + 2072);
    t21 = (t0 + 7240);
    t22 = 0;
    xsi_delete_subprogram_invocation(t19, t20, t0, t21, t22);
    xsi_set_current_line(177, ng0);
    t2 = ((char*)((ng5)));
    t3 = (t0 + 7240);
    t8 = (t0 + 2504);
    t9 = xsi_create_subprogram_invocation(t3, 0, t0, t8, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t8, t9);
    t10 = (t0 + 5776);
    xsi_vlogvar_assign_value(t10, t2, 0, 0, 13);

LAB17:    t11 = (t0 + 7336);
    t12 = *((char **)t11);
    t13 = (t12 + 80U);
    t14 = *((char **)t13);
    t15 = (t14 + 272U);
    t16 = *((char **)t15);
    t17 = (t16 + 0U);
    t18 = *((char **)t17);
    t7 = ((int  (*)(char *, char *))t18)(t0, t12);

LAB19:    if (t7 != 0)
        goto LAB20;

LAB15:    t12 = (t0 + 2504);
    xsi_vlog_subprogram_popinvocation(t12);

LAB16:    t19 = (t0 + 7336);
    t20 = *((char **)t19);
    t19 = (t0 + 2504);
    t21 = (t0 + 7240);
    t22 = 0;
    xsi_delete_subprogram_invocation(t19, t20, t0, t21, t22);
    xsi_set_current_line(178, ng0);
    t2 = ((char*)((ng5)));
    t3 = (t0 + 7240);
    t8 = (t0 + 2072);
    t9 = xsi_create_subprogram_invocation(t3, 0, t0, t8, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t8, t9);
    t10 = (t0 + 5616);
    xsi_vlogvar_assign_value(t10, t2, 0, 0, 4);

LAB23:    t11 = (t0 + 7336);
    t12 = *((char **)t11);
    t13 = (t12 + 80U);
    t14 = *((char **)t13);
    t15 = (t14 + 272U);
    t16 = *((char **)t15);
    t17 = (t16 + 0U);
    t18 = *((char **)t17);
    t7 = ((int  (*)(char *, char *))t18)(t0, t12);

LAB25:    if (t7 != 0)
        goto LAB26;

LAB21:    t12 = (t0 + 2072);
    xsi_vlog_subprogram_popinvocation(t12);

LAB22:    t19 = (t0 + 7336);
    t20 = *((char **)t19);
    t19 = (t0 + 2072);
    t21 = (t0 + 7240);
    t22 = 0;
    xsi_delete_subprogram_invocation(t19, t20, t0, t21, t22);
    xsi_set_current_line(179, ng0);
    t2 = ((char*)((ng6)));
    t3 = (t0 + 7240);
    t8 = (t0 + 2072);
    t9 = xsi_create_subprogram_invocation(t3, 0, t0, t8, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t8, t9);
    t10 = (t0 + 5616);
    xsi_vlogvar_assign_value(t10, t2, 0, 0, 4);

LAB29:    t11 = (t0 + 7336);
    t12 = *((char **)t11);
    t13 = (t12 + 80U);
    t14 = *((char **)t13);
    t15 = (t14 + 272U);
    t16 = *((char **)t15);
    t17 = (t16 + 0U);
    t18 = *((char **)t17);
    t7 = ((int  (*)(char *, char *))t18)(t0, t12);

LAB31:    if (t7 != 0)
        goto LAB32;

LAB27:    t12 = (t0 + 2072);
    xsi_vlog_subprogram_popinvocation(t12);

LAB28:    t19 = (t0 + 7336);
    t20 = *((char **)t19);
    t19 = (t0 + 2072);
    t21 = (t0 + 7240);
    t22 = 0;
    xsi_delete_subprogram_invocation(t19, t20, t0, t21, t22);
    xsi_set_current_line(180, ng0);
    t2 = ((char*)((ng7)));
    t3 = (t0 + 7240);
    t8 = (t0 + 2504);
    t9 = xsi_create_subprogram_invocation(t3, 0, t0, t8, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t8, t9);
    t10 = (t0 + 5776);
    xsi_vlogvar_assign_value(t10, t2, 0, 0, 13);

LAB35:    t11 = (t0 + 7336);
    t12 = *((char **)t11);
    t13 = (t12 + 80U);
    t14 = *((char **)t13);
    t15 = (t14 + 272U);
    t16 = *((char **)t15);
    t17 = (t16 + 0U);
    t18 = *((char **)t17);
    t7 = ((int  (*)(char *, char *))t18)(t0, t12);

LAB37:    if (t7 != 0)
        goto LAB38;

LAB33:    t12 = (t0 + 2504);
    xsi_vlog_subprogram_popinvocation(t12);

LAB34:    t19 = (t0 + 7336);
    t20 = *((char **)t19);
    t19 = (t0 + 2504);
    t21 = (t0 + 7240);
    t22 = 0;
    xsi_delete_subprogram_invocation(t19, t20, t0, t21, t22);
    xsi_set_current_line(181, ng0);
    t2 = ((char*)((ng7)));
    t3 = (t0 + 7240);
    t8 = (t0 + 2504);
    t9 = xsi_create_subprogram_invocation(t3, 0, t0, t8, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t8, t9);
    t10 = (t0 + 5776);
    xsi_vlogvar_assign_value(t10, t2, 0, 0, 13);

LAB41:    t11 = (t0 + 7336);
    t12 = *((char **)t11);
    t13 = (t12 + 80U);
    t14 = *((char **)t13);
    t15 = (t14 + 272U);
    t16 = *((char **)t15);
    t17 = (t16 + 0U);
    t18 = *((char **)t17);
    t7 = ((int  (*)(char *, char *))t18)(t0, t12);

LAB43:    if (t7 != 0)
        goto LAB44;

LAB39:    t12 = (t0 + 2504);
    xsi_vlog_subprogram_popinvocation(t12);

LAB40:    t19 = (t0 + 7336);
    t20 = *((char **)t19);
    t19 = (t0 + 2504);
    t21 = (t0 + 7240);
    t22 = 0;
    xsi_delete_subprogram_invocation(t19, t20, t0, t21, t22);
    xsi_set_current_line(194, ng0);
    t2 = ((char*)((ng8)));
    t3 = (t2 + 4);
    t4 = *((unsigned int *)t3);
    t5 = (~(t4));
    t6 = *((unsigned int *)t2);
    t7 = (t6 & t5);
    t8 = (t0 + 10576);
    *((int *)t8) = t7;

LAB45:    t9 = (t0 + 10576);
    if (*((int *)t9) > 0)
        goto LAB46;

LAB47:    xsi_set_current_line(194, ng0);
    xsi_vlog_finish(1);

LAB1:    return;
LAB6:    xsi_set_current_line(174, ng0);
    t10 = (t0 + 8408);
    *((int *)t10) = 1;
    t11 = (t0 + 7464);
    *((char **)t11) = t10;
    *((char **)t1) = &&LAB8;
    goto LAB1;

LAB8:    t2 = (t0 + 10572);
    t7 = *((int *)t2);
    *((int *)t2) = (t7 - 1);
    goto LAB5;

LAB12:;
LAB14:    t11 = (t0 + 7432U);
    *((char **)t11) = &&LAB11;
    goto LAB1;

LAB18:;
LAB20:    t11 = (t0 + 7432U);
    *((char **)t11) = &&LAB17;
    goto LAB1;

LAB24:;
LAB26:    t11 = (t0 + 7432U);
    *((char **)t11) = &&LAB23;
    goto LAB1;

LAB30:;
LAB32:    t11 = (t0 + 7432U);
    *((char **)t11) = &&LAB29;
    goto LAB1;

LAB36:;
LAB38:    t11 = (t0 + 7432U);
    *((char **)t11) = &&LAB35;
    goto LAB1;

LAB42:;
LAB44:    t11 = (t0 + 7432U);
    *((char **)t11) = &&LAB41;
    goto LAB1;

LAB46:    xsi_set_current_line(194, ng0);
    t10 = (t0 + 8424);
    *((int *)t10) = 1;
    t11 = (t0 + 7464);
    *((char **)t11) = t10;
    *((char **)t1) = &&LAB48;
    goto LAB1;

LAB48:    t2 = (t0 + 10576);
    t7 = *((int *)t2);
    *((int *)t2) = (t7 - 1);
    goto LAB45;

}


extern void work_m_17736614029205542775_2203842397_init()
{
	static char *pe[] = {(void *)Always_92_0,(void *)Always_96_1,(void *)Initial_100_2,(void *)Initial_172_3};
	static char *se[] = {(void *)sp_command,(void *)sp_data};
	xsi_register_didat("work_m_17736614029205542775_2203842397", "isim/main_module_tb_isim_beh.exe.sim/work/m_17736614029205542775_2203842397.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}
